#pragma once
#include <QDialog>

class QLineEdit;
class QCheckBox;

class SettingsDialog : public QDialog {
    Q_OBJECT

public:
    explicit SettingsDialog(QWidget* parent = nullptr);

    QString apiKey() const;
    void    setApiKey(const QString& key);

private:
    QLineEdit* m_keyEdit;
    QCheckBox* m_showKeyCheck;
};
