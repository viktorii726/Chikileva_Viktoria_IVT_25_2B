#pragma once
#include <QWizard>
#include <QWizardPage>
#include "StoryData.h"

class QLineEdit;
class QComboBox;
class QButtonGroup;
class QLabel;
class QPushButton;
class QRadioButton;

// ──────────────────────────────────────────────────────
//  Отдельные страницы мастера
// ──────────────────────────────────────────────────────

class WelcomePage : public QWizardPage {
    Q_OBJECT
public:
    explicit WelcomePage(QWidget* parent = nullptr);
    bool isComplete() const override;
    QString childName() const;
    AgeGroup ageGroup() const;

private:
    QLineEdit*    m_nameEdit;
    QButtonGroup* m_ageGroup;
};

class HeroPage : public QWizardPage {
    Q_OBJECT
public:
    explicit HeroPage(QWidget* parent = nullptr);
    bool isComplete() const override;
    QString hero()      const;
    QString heroTrait() const;

private:
    void selectHero(const QString& name);
    QLineEdit*    m_heroEdit;
    QComboBox*    m_traitCombo;
    QPushButton*  m_selectedBtn = nullptr;
};

class PlacePage : public QWizardPage {
    Q_OBJECT
public:
    explicit PlacePage(QWidget* parent = nullptr);
    bool isComplete() const override;
    QString place() const;

private:
    void selectPlace(const QString& name);
    QLineEdit*   m_placeEdit;
    QPushButton* m_selectedBtn = nullptr;
};

class AdventurePage : public QWizardPage {
    Q_OBJECT
public:
    explicit AdventurePage(QWidget* parent = nullptr);
    bool isComplete() const override;
    QString problem()   const;
    QString helper()    const;
    QString magicItem() const;
    EndingType ending() const;

private:
    QLineEdit*    m_problemEdit;
    QComboBox*    m_helperCombo;
    QLineEdit*    m_magicEdit;
    QButtonGroup* m_endingGroup;
};

// ──────────────────────────────────────────────────────
//  Сам мастер (QWizard)
// ──────────────────────────────────────────────────────

class StoryWizard : public QWizard {
    Q_OBJECT

public:
    explicit StoryWizard(QWidget* parent = nullptr);
    StoryData storyData() const;

private:
    WelcomePage*   m_welcomePage;
    HeroPage*      m_heroPage;
    PlacePage*     m_placePage;
    AdventurePage* m_adventurePage;

    // Общий стиль кнопок-плиток
    static QPushButton* makeTileButton(const QString& emoji,
                                       const QString& label,
                                       QWidget* parent);
};
