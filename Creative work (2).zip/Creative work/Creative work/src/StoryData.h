#pragma once
#include <QString>
#include <QDateTime>

// Возрастные группы
enum class AgeGroup {
    Little   = 0,  // 3–5 лет
    Middle   = 1,  // 6–8 лет
    Older    = 2   // 9–12 лет
};

// Тип концовки
enum class EndingType {
    Happy       = 0,  // Счастливый конец
    Educational = 1,  // Поучительный
    Adventure   = 2   // Продолжение следует
};

// Полная структура данных сказки
struct StoryData {
    // Параметры от ребёнка
    QString   childName;      // Имя ребёнка
    AgeGroup  ageGroup   = AgeGroup::Middle;
    QString   hero;           // Главный герой
    QString   heroTrait;      // Черта характера (добрый, смелый...)
    QString   place;          // Место действия
    QString   problem;        // Главная проблема
    QString   helper;         // Помощник
    QString   magicItem;      // Волшебный предмет (опционально)
    EndingType ending    = EndingType::Happy;

    // Сгенерированный контент
    QString   title;          // Название сказки
    QString   text;           // Текст сказки

    // Метаданные
    QDateTime createdAt;
    int       id = -1;        // ID в базе данных

    // Удобный метод для отладки
    QString toString() const {
        return QString("Герой: %1, Место: %2, Проблема: %3")
            .arg(hero, place, problem);
    }
};
