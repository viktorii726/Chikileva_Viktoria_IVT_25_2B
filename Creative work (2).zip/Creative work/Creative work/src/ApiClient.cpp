#include "ApiClient.h"
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QNetworkRequest>
#include <QNetworkReply>

// Yandex Foundation Models API
const QString ApiClient::API_URL = "https://llm.api.cloud.yandex.net/foundationModels/v1/completion";
// Модель: yandexgpt-lite (бесплатная) или yandexgpt (более мощная)
const QString ApiClient::MODEL   = "yandexgpt-5-lite/latest";

ApiClient::ApiClient(QObject* parent)
    : QObject(parent)
    , m_network(new QNetworkAccessManager(this))
{}

void ApiClient::generateStory(const StoryData& data) {
    if (m_apiKey.isEmpty()) {
        emit errorOccurred("API ключ не установлен. Перейдите в Настройки.");
        return;
    }

    emit requestStarted();

    QNetworkRequest request;
    request.setUrl(QUrl(API_URL));
    request.setHeader(QNetworkRequest::ContentTypeHeader, QString("application/json; charset=utf-8"));

    // Yandex API: заголовок авторизации — "Api-Key <ключ>"
    QString authHeader = QString("Api-Key ") + m_apiKey;
    request.setRawHeader(QByteArray("Authorization"), authHeader.toUtf8());
    request.setRawHeader(QByteArray("Accept-Charset"), QByteArray("utf-8"));

    // Формат тела запроса Yandex Foundation Models
    QJsonObject body;

    body["modelUri"] =
        "gpt://b1gihoie5cdtiv5capve/yandexgpt-5-lite/latest";

    QJsonObject completionOptions;
    completionOptions["stream"] = false;
    completionOptions["temperature"] = 0.7;
    completionOptions["maxTokens"] = 2000;

    body["completionOptions"] = completionOptions;

    // Сообщения в формате Yandex (role: "system" / "user")
    QJsonArray messages;

    QJsonObject sysMsg;
    sysMsg["role"] = QString("system");
    sysMsg["text"] = buildSystemPrompt(data);
    messages.append(sysMsg);

    QJsonObject userMsg;
    userMsg["role"] = QString("user");
    userMsg["text"] = buildPrompt(data);
    messages.append(userMsg);

    body["messages"] = messages;

    QByteArray bodyBytes = QJsonDocument(body).toJson(QJsonDocument::Compact);
    QNetworkReply* reply = m_network->post(request, bodyBytes);

    connect(reply, &QNetworkReply::finished, this, [=]() {
        reply->deleteLater();

        if (reply->error() != QNetworkReply::NoError) {
            emit errorOccurred(QString("Ошибка сети: ") + reply->errorString());
            return;
        }

        QByteArray responseData = reply->readAll();
        QString responseStr = QString::fromUtf8(responseData);

        QJsonDocument doc = QJsonDocument::fromJson(responseStr.toUtf8());
        QJsonObject   obj = doc.object();

        // Обработка ошибки от Yandex API
        if (obj.contains("error")) {
            QJsonObject errObj = obj["error"].toObject();
            QString errMsg = errObj.contains("message")
                ? errObj["message"].toString()
                : obj["error"].toString();
            emit errorOccurred(QString("Ошибка API: ") + errMsg);
            return;
        }

        // Структура ответа Yandex: result.alternatives[0].message.text
        QString fullText = obj["result"]
                               .toObject()["alternatives"]
                               .toArray().at(0)
                               .toObject()["message"]
                               .toObject()["text"]
                               .toString()
                               .trimmed();

        if (fullText.isEmpty()) {
            emit errorOccurred("Получен пустой ответ от API.");
            return;
        }

        QString title, storyText;
        int nlIdx = fullText.indexOf('\n');
        if (nlIdx > 0 && nlIdx < 80) {
            title     = fullText.left(nlIdx).remove('#').trimmed();
            storyText = fullText.mid(nlIdx + 1).trimmed();
        } else {
            title     = QString("Сказка про ") + data.hero;
            storyText = fullText;
        }

        emit storyReady(title, storyText);
    });
}

QString ApiClient::buildSystemPrompt(const StoryData& data) const {
    QString result;
    result += "Ты мастер детских сказок. ";
    result += "Пиши волшебные, добрые и увлекательные сказки на русском языке для детей ";
    result += ageGroupStr(data.ageGroup);
    result += ". ";
    result += "Пиши ТОЛЬКО на русском языке. ";
    result += "Начинай с названия сказки на первой строке. ";
    result += "Используй имя ребёнка ";
    result += data.childName;
    result += " один раз в конце сказки.";
    return result;
}

QString ApiClient::buildPrompt(const StoryData& data) const {
    QString prompt;
    prompt += "Напиши детскую сказку на русском языке:\n\n";
    prompt += "Главный герой: " + data.hero + "\n";
    prompt += "Черта характера: " + data.heroTrait + "\n";
    prompt += "Место действия: " + data.place + "\n";
    prompt += "Главная проблема: " + data.problem + "\n";
    prompt += "Помощник: " + data.helper + "\n";

    if (!data.magicItem.isEmpty()) {
        prompt += "Волшебный предмет: " + data.magicItem + "\n";
    }

    prompt += "Концовка: " + endingTypeStr(data.ending) + "\n\n";
    prompt += "Длина сказки: 350-450 слов. Весь текст только на русском языке!";

    return prompt;
}

QString ApiClient::ageGroupStr(AgeGroup ag) const {
    switch (ag) {
        case AgeGroup::Little: return QString("3-5 лет");
        case AgeGroup::Middle: return QString("6-8 лет");
        case AgeGroup::Older:  return QString("9-12 лет");
    }
    return QString();
}

QString ApiClient::endingTypeStr(EndingType et) const {
    switch (et) {
        case EndingType::Happy:       return QString("счастливый");
        case EndingType::Educational: return QString("поучительный");
        case EndingType::Adventure:   return QString("открытый");
    }
    return QString();
}
