#include "SettingsDialog.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QCheckBox>
#include <QPushButton>
#include <QDesktopServices>
#include <QUrl>

SettingsDialog::SettingsDialog(QWidget* parent) : QDialog(parent) {
    setWindowTitle("⚙️ Настройки");
    setMinimumSize(520, 400);
    resize(520, 420);

    // Глобальные стили — только для верхнего уровня, не для вложенных QWidget
    setStyleSheet(R"(
        QDialog    { background: #faf7ff; }
        QLabel     { color: #3a2070; background: transparent; }
        QLineEdit  {
            font-size: 14px; padding: 8px 12px;
            border: 2px solid #c8b8f0; border-radius: 8px;
            background: white; color: #2d1a5e;
        }
        QLineEdit:focus { border-color: #7c4dbd; }
        QCheckBox  { font-size: 13px; color: #7a6090; background: transparent; }
    )");

    auto* root = new QVBoxLayout(this);
    root->setSpacing(14);
    root->setContentsMargins(24, 24, 24, 24);

    // Заголовок
    auto* title = new QLabel("⚙️ Настройки Yandex GPT", this);
    title->setStyleSheet("font-size: 18px; font-weight: bold; color: #4a1fa6;");

    // ─── Блок API ключа ───────────────────────────────────────────────
    auto* keyGroup = new QWidget(this);
    // Используем objectName, чтобы стиль не «протекал» в дочерние виджеты
    keyGroup->setObjectName("keyGroup");
    keyGroup->setStyleSheet(R"(
        QWidget#keyGroup {
            background: #f0e8ff;
            border: 2px solid #d0c0f0;
            border-radius: 10px;
        }
    )");
    auto* keyLayout = new QVBoxLayout(keyGroup);
    keyLayout->setContentsMargins(16, 14, 16, 14);
    keyLayout->setSpacing(6);

    auto* keyTitle = new QLabel("🔑 API Ключ Yandex Cloud", keyGroup);
    keyTitle->setStyleSheet("font-size: 14px; font-weight: bold; color: #4a1fa6;");

    auto* keyHint = new QLabel(
        "Создайте сервисный аккаунт и ключ на "
        "<a href='https://console.yandex.cloud/'>console.yandex.cloud</a>",
        keyGroup
    );
    keyHint->setStyleSheet("font-size: 12px; color: #7a6090;");
    keyHint->setOpenExternalLinks(true);

    m_keyEdit = new QLineEdit(keyGroup);
    m_keyEdit->setPlaceholderText("AQVN...");
    m_keyEdit->setEchoMode(QLineEdit::Password);

    m_showKeyCheck = new QCheckBox("Показать ключ", keyGroup);
    connect(m_showKeyCheck, &QCheckBox::toggled, this, [=](bool checked) {
        m_keyEdit->setEchoMode(checked ? QLineEdit::Normal : QLineEdit::Password);
    });

    keyLayout->addWidget(keyTitle);
    keyLayout->addWidget(keyHint);
    keyLayout->addWidget(m_keyEdit);
    keyLayout->addWidget(m_showKeyCheck);

    // ─── Кнопки ───────────────────────────────────────────────────────
    auto* btnLayout = new QHBoxLayout;
    auto* cancelBtn = new QPushButton("Отмена", this);
    auto* saveBtn   = new QPushButton("💾 Сохранить", this);

    cancelBtn->setStyleSheet(R"(
        QPushButton {
            font-size: 13px; padding: 8px 16px;
            border: none; border-radius: 8px;
            background: #ede0ff; color: #4a1fa6;
        }
    )");
    saveBtn->setStyleSheet(R"(
        QPushButton {
            font-size: 13px; font-weight: bold; padding: 8px 20px;
            border: none; border-radius: 8px;
            background: #7c4dbd; color: white;
        }
    )");

    connect(cancelBtn, &QPushButton::clicked, this, &QDialog::reject);
    connect(saveBtn,   &QPushButton::clicked, this, &QDialog::accept);

    btnLayout->addStretch();
    btnLayout->addWidget(cancelBtn);
    btnLayout->addWidget(saveBtn);

    root->addWidget(title);
    root->addWidget(keyGroup);
    root->addStretch();
    root->addLayout(btnLayout);
}

QString SettingsDialog::apiKey() const {
    return m_keyEdit->text().trimmed();
}

void SettingsDialog::setApiKey(const QString& key) {
    m_keyEdit->setText(key);
}
