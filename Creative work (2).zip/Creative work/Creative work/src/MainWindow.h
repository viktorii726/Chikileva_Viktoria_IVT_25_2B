#pragma once
#include <QMainWindow>
#include "StoryData.h"

class ApiClient;
class Database;
class StoryDisplay;
class QStackedWidget;
class QLabel;
class QPushButton;

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    explicit MainWindow(QWidget* parent = nullptr);
    ~MainWindow();

private slots:
    void onNewStory();
    void onOpenSaved();
    void onSettings();
    void onStoryReady(const QString& title, const QString& text);
    void onApiError(const QString& error);
    void onSaveStory();
    void onPrintStory();
    void onShowSavedStory(const StoryData& story);

private:
    void setupUi();
    void showMainMenu();
    void showStoryScreen();
    void loadSettings();
    void saveSettings();
    bool checkApiKey();

    // Основные виджеты
    QStackedWidget* m_stack;
    QWidget*        m_menuPage;
    QWidget*        m_storyPage;
    StoryDisplay*   m_storyDisplay;

    // Сервисы
    ApiClient* m_apiClient;
    Database*  m_db;

    // Текущая сказка
    StoryData m_currentStory;
    bool      m_storySaved = false;
};
