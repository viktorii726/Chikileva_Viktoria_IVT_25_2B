#include "StoryDisplay.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QTextEdit>
#include <QLabel>
#include <QPushButton>
#include <QProgressBar>
#include <QSlider>
#include <QTextToSpeech>
#include <QPrinter>
#include <QPrintDialog>
#include <QTextDocument>

#include <QFont>
#include <QLocale>
#include <QScrollBar>

StoryDisplay::StoryDisplay(QWidget* parent) : QWidget(parent) {
    m_typeTimer = new QTimer(this);
    connect(m_typeTimer, &QTimer::timeout, this, &StoryDisplay::onTypewriterTick);

    // Инициализация TTS — выбираем наилучший доступный движок
    // Приоритет: windows (SAPI5 с новыми голосами) > speechd > flite
    QStringList preferredEngines = {"windows", "macos", "speechd", "flite"};
    QString chosenEngine;
    for (const QString& eng : QTextToSpeech::availableEngines()) {
        if (preferredEngines.contains(eng)) {
            chosenEngine = eng;
            break;
        }
    }
    m_tts = chosenEngine.isEmpty()
                ? new QTextToSpeech(this)
                : new QTextToSpeech(chosenEngine, this);

    // Устанавливаем русский язык
    QLocale ruLocale(QLocale::Russian);
    m_tts->setLocale(ruLocale);

    // Ищем женский голос — он звучит мягче и приятнее для детских сказок
    QVoice bestVoice;
    bool voiceFound = false;
    for (const QVoice& v : m_tts->availableVoices()) {
        if (v.gender() == QVoice::Female) {
            bestVoice = v;
            voiceFound = true;
            break;
        }
    }
    // Если женского нет — берём первый доступный
    if (!voiceFound && !m_tts->availableVoices().isEmpty()) {
        bestVoice = m_tts->availableVoices().first();
    }
    if (voiceFound || !m_tts->availableVoices().isEmpty()) {
        m_tts->setVoice(bestVoice);
    }

    // Чуть медленнее стандартного — лучше воспринимается детьми
    m_tts->setRate(-0.1);   // от -1.0 до 1.0, 0 — норма
    m_tts->setVolume(1.0);  // максимальная громкость

    // Подключаем один раз (не внутри onSpeakToggle!)
    connect(m_tts, &QTextToSpeech::stateChanged, this, [=](QTextToSpeech::State state) {
        if (state == QTextToSpeech::Ready && m_speaking) {
            m_speakBtn->setText("🔊 Читать вслух");
            m_speaking = false;
        }
    });

    setupUi();
}

void StoryDisplay::setupUi() {
    auto* root = new QVBoxLayout(this);
    root->setSpacing(0);
    root->setContentsMargins(0, 0, 0, 0);

    setStyleSheet(R"(
        QWidget { background: #faf7ff; }
    )");

    // ── Заголовок ──────────────────────────────────
    auto* headerWidget = new QWidget(this);
    headerWidget->setStyleSheet("background: #4a1fa6; border-radius: 0px;");
    auto* headerLayout = new QVBoxLayout(headerWidget);
    headerLayout->setContentsMargins(24, 20, 24, 20);

    m_titleLabel = new QLabel("📖", headerWidget);
    m_titleLabel->setStyleSheet(R"(
        QLabel {
            font-size: 22px;
            font-weight: bold;
            color: white;
            background: transparent;
        }
    )");
    m_titleLabel->setWordWrap(true);
    m_titleLabel->setAlignment(Qt::AlignCenter);
    headerLayout->addWidget(m_titleLabel);

    // ── Прогресс загрузки ──────────────────────────
    m_progress = new QProgressBar(this);
    m_progress->setRange(0, 0); // Бесконечный
    m_progress->setFixedHeight(6);
    m_progress->setStyleSheet(R"(
        QProgressBar {
            border: none;
            background: #e8deff;
        }
        QProgressBar::chunk {
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                stop:0 #9b72cf, stop:1 #6a3fa6);
        }
    )");
    m_progress->hide();

    // ── Статус ─────────────────────────────────────
    m_statusLabel = new QLabel(this);
    m_statusLabel->setAlignment(Qt::AlignCenter);
    m_statusLabel->setStyleSheet(R"(
        QLabel {
            font-size: 15px;
            color: #7a6090;
            padding: 20px;
        }
    )");
    m_statusLabel->hide();

    // ── Текст сказки ───────────────────────────────
    m_textEdit = new QTextEdit(this);
    m_textEdit->setReadOnly(true);
    m_textEdit->setStyleSheet(R"(
        QTextEdit {
            font-size: 16px;
            line-height: 170%;
            color: #2d1a5e;
            background: transparent;
            border: none;
            padding: 20px 28px;
            selection-background-color: #d4b8ff;
        }
    )");

    // Шрифт — красивый для чтения
    QFont storyFont("Georgia", 15);
    storyFont.setStyleStrategy(QFont::PreferAntialias);
    m_textEdit->setFont(storyFont);
    m_textEdit->hide();

    // ── Панель управления ──────────────────────────
    auto* toolbar = new QWidget(this);
    toolbar->setStyleSheet(R"(
        QWidget {
            background: #f0e8ff;
            border-top: 1px solid #d8c8f8;
        }
    )");
    toolbar->setFixedHeight(70);
    auto* toolLayout = new QHBoxLayout(toolbar);
    toolLayout->setContentsMargins(16, 10, 16, 10);
    toolLayout->setSpacing(10);

    auto makeBtn = [](const QString& text, const QString& color) -> QPushButton* {
        auto* btn = new QPushButton(text);
        btn->setStyleSheet(QString(R"(
            QPushButton {
                font-size: 13px;
                font-weight: bold;
                padding: 8px 14px;
                border: none;
                border-radius: 8px;
                background: %1;
                color: white;
            }
            QPushButton:hover { opacity: 0.85; }
            QPushButton:disabled { background: #ccc; }
        )").arg(color));
        return btn;
    };

    m_speakBtn = makeBtn("🔊 Читать вслух", "#7c4dbd");
    m_saveBtn  = makeBtn("💾 Сохранить",    "#27ae60");
    m_printBtn = makeBtn("🖨️ Напечатать",   "#2980b9");
    m_newBtn   = makeBtn("✨ Новая сказка", "#e67e22");

    m_saveBtn->setEnabled(false);
    m_printBtn->setEnabled(false);
    m_speakBtn->setEnabled(false);

    // Скорость печати
    auto* speedLabel = new QLabel("🐇", toolbar);
    m_speedSlider = new QSlider(Qt::Horizontal, toolbar);
    m_speedSlider->setRange(5, 60);
    m_speedSlider->setValue(20);
    m_speedSlider->setFixedWidth(70);
    m_speedSlider->setToolTip("Скорость появления текста");
    auto* speedLabel2 = new QLabel("🐢", toolbar);

    toolLayout->addWidget(m_speakBtn);
    toolLayout->addWidget(m_saveBtn);
    toolLayout->addWidget(m_printBtn);
    toolLayout->addStretch();
    toolLayout->addWidget(speedLabel);
    toolLayout->addWidget(m_speedSlider);
    toolLayout->addWidget(speedLabel2);
    toolLayout->addWidget(m_newBtn);

    // Подключаем сигналы
    connect(m_speakBtn, &QPushButton::clicked, this, &StoryDisplay::onSpeakToggle);
    connect(m_saveBtn,  &QPushButton::clicked, this, &StoryDisplay::saveRequested);
    connect(m_newBtn,   &QPushButton::clicked, this, &StoryDisplay::newStoryRequested);
    connect(m_printBtn, &QPushButton::clicked, this, &StoryDisplay::printRequested);

    root->addWidget(headerWidget);
    root->addWidget(m_progress);
    root->addWidget(m_statusLabel, 1);
    root->addWidget(m_textEdit, 1);
    root->addWidget(toolbar);
}

// ─── Состояние: загрузка ─────────────────────────────

void StoryDisplay::showLoading() {
    stopTypewriter();
    m_titleLabel->setText("⏳ Пишем сказку...");
    m_textEdit->hide();
    m_statusLabel->setText(
        "🪄 Волшебство происходит...\n\nСказка создаётся специально для тебя!"
    );
    m_statusLabel->show();
    m_progress->show();
    m_saveBtn->setEnabled(false);
    m_printBtn->setEnabled(false);
    m_speakBtn->setEnabled(false);
}

// ─── Состояние: сказка готова ────────────────────────

void StoryDisplay::showStory(const StoryData& story) {
    m_currentStory = story;

    m_progress->hide();
    m_statusLabel->hide();
    m_textEdit->show();
    m_textEdit->clear();

    // Заголовок
    m_titleLabel->setText("📖 " + story.title);

    // Запускаем эффект печатной машинки
    startTypewriter(story.text);
}

// ─── Состояние: ошибка ───────────────────────────────

void StoryDisplay::showError(const QString& message) {
    stopTypewriter();
    m_titleLabel->setText("❌ Ошибка");
    m_progress->hide();
    m_statusLabel->setText("😔 Что-то пошло не так:\n\n" + message +
                            "\n\nПроверьте API ключ в Настройках.");
    m_statusLabel->show();
    m_textEdit->hide();
}

// ─── Typewriter ──────────────────────────────────────

void StoryDisplay::startTypewriter(const QString& text) {
    m_fullText   = text;
    m_currentPos = 0;
    // Интервал из слайдера (мс/символ)
    m_typeTimer->start(m_speedSlider->value());
}

void StoryDisplay::stopTypewriter() {
    if (m_typeTimer->isActive()) {
        m_typeTimer->stop();
        // Дописываем оставшееся мгновенно
        if (m_currentPos < m_fullText.size()) {
            m_textEdit->setPlainText(m_fullText);
        }
    }
}

void StoryDisplay::onTypewriterTick() {
    if (m_currentPos >= m_fullText.size()) {
        m_typeTimer->stop();
        // Сказка полностью напечатана — разблокируем кнопки
        m_saveBtn->setEnabled(true);
        m_printBtn->setEnabled(true);
        m_speakBtn->setEnabled(true);
        return;
    }

    // Добавляем символы порциями для скорости
    int batch = qMax(1, 60 / m_speedSlider->value());
    int end   = qMin(m_currentPos + batch, m_fullText.size());
    m_textEdit->insertPlainText(m_fullText.mid(m_currentPos, end - m_currentPos));
    m_currentPos = end;

    // Прокрутка вниз
    auto* sb = m_textEdit->verticalScrollBar();
    sb->setValue(sb->maximum());
}

// ─── TTS ─────────────────────────────────────────────

void StoryDisplay::onSpeakToggle() {
    if (m_speaking) {
        m_tts->stop();
        m_speakBtn->setText("🔊 Читать вслух");
        m_speaking = false;
    } else {
        // Если typewriter ещё работает — сначала завершаем его
        stopTypewriter();
        m_tts->say(m_currentStory.text);
        m_speakBtn->setText("⏹ Остановить");
        m_speaking = true;
    }
}

// ─── Печать ──────────────────────────────────────────

void StoryDisplay::printStory() {
    QPrinter printer(QPrinter::HighResolution);
    QPrintDialog dialog(&printer, this);
    dialog.setWindowTitle("Распечатать сказку");

    if (dialog.exec() != QDialog::Accepted) return;

    QTextDocument doc;
    doc.setHtml(QString(R"(
        <h2 style='color:#4a1fa6; text-align:center;'>%1</h2>
        <hr/>
        <p style='font-size:14pt; line-height:180%%;'>%2</p>
        <p style='text-align:right; color:gray; font-size:10pt;'>
            Создано специально для %3 🌟
        </p>
    )").arg(
        m_currentStory.title.toHtmlEscaped(),
        m_currentStory.text.toHtmlEscaped().replace("\n", "<br>"),
        m_currentStory.childName.toHtmlEscaped()
    ));
    doc.print(&printer);
}
