#pragma once
#include <QDialog>
#include "StoryData.h"
#include "Database.h"

class QListWidget;
class QTextEdit;
class QLabel;
class QPushButton;

class SavedStoriesDialog : public QDialog {
    Q_OBJECT

public:
    explicit SavedStoriesDialog(Database* db, QWidget* parent = nullptr);

signals:
    void storySelected(const StoryData& story);

private slots:
    void onStoryClicked(int row);
    void onDeleteClicked();
    void onOpenClicked();

private:
    void loadList();

    Database*    m_db;
    QListWidget* m_list;
    QTextEdit*   m_preview;
    QLabel*      m_emptyLabel;
    QPushButton* m_deleteBtn;
    QPushButton* m_openBtn;

    QList<StoryData> m_stories;
    int              m_selectedId = -1;
};
