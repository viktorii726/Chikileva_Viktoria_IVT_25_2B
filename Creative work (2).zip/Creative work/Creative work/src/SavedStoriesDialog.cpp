#include "SavedStoriesDialog.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QSplitter>
#include <QListWidget>
#include <QTextEdit>
#include <QLabel>
#include <QPushButton>
#include <QMessageBox>

SavedStoriesDialog::SavedStoriesDialog(Database* db, QWidget* parent)
    : QDialog(parent), m_db(db)
{
    setWindowTitle("📚 Сохранённые сказки");
    resize(700, 500);

    setStyleSheet(R"(
        QDialog    { background: #faf7ff; }
        QSplitter  { background: #faf7ff; }
        QListWidget {
            font-size: 14px;
            border: 2px solid #d0c0f0;
            border-radius: 10px;
            padding: 4px;
            background: white;
        }
        QListWidget::item {
            padding: 10px 8px;
            border-radius: 6px;
            color: #2d1a5e;
        }
        QListWidget::item:selected {
            background: #ede0ff;
            color: #4a1fa6;
        }
        QListWidget::item:hover { background: #f5eeff; }
        QTextEdit {
            font-size: 14px;
            border: 2px solid #d0c0f0;
            border-radius: 10px;
            padding: 12px;
            background: white;
            color: #2d1a5e;
        }
    )");

    auto* root = new QVBoxLayout(this);

    auto* title = new QLabel("📚 Мои сказки", this);
    title->setStyleSheet("font-size: 20px; font-weight: bold; color: #4a1fa6; padding: 8px;");

    auto* splitter = new QSplitter(Qt::Horizontal, this);

    // Левая панель — список
    auto* listPanel = new QWidget;
    auto* listLayout = new QVBoxLayout(listPanel);
    listLayout->setContentsMargins(0,0,0,0);

    m_list = new QListWidget(listPanel);
    m_emptyLabel = new QLabel("Пока нет сохранённых сказок.\nСоздайте первую! ✨", listPanel);
    m_emptyLabel->setAlignment(Qt::AlignCenter);
    m_emptyLabel->setStyleSheet("font-size: 14px; color: #9a80c0; padding: 30px;");

    listLayout->addWidget(m_list);
    listLayout->addWidget(m_emptyLabel);

    // Правая панель — превью
    m_preview = new QTextEdit(this);
    m_preview->setReadOnly(true);
    m_preview->setPlaceholderText("Выберите сказку из списка, чтобы увидеть её...");

    splitter->addWidget(listPanel);
    splitter->addWidget(m_preview);
    splitter->setSizes({260, 420});

    // Кнопки
    auto* btnLayout = new QHBoxLayout;
    m_deleteBtn = new QPushButton("🗑️ Удалить", this);
    m_openBtn   = new QPushButton("📖 Открыть", this);
    auto* closeBtn  = new QPushButton("Закрыть",    this);

    auto btnStyle = [](const QString& bg, const QString& fg) {
        return QString(R"(
            QPushButton {
                font-size: 13px; font-weight: bold;
                padding: 8px 16px; border: none; border-radius: 8px;
                background: %1; color: %2;
            }
        )").arg(bg, fg);
    };

    m_deleteBtn->setStyleSheet(btnStyle("#e74c3c", "white"));
    m_openBtn->setStyleSheet(btnStyle("#7c4dbd", "white"));
    closeBtn->setStyleSheet(btnStyle("#ede0ff", "#4a1fa6"));

    m_deleteBtn->setEnabled(false);
    m_openBtn->setEnabled(false);

    btnLayout->addWidget(m_deleteBtn);
    btnLayout->addStretch();
    btnLayout->addWidget(closeBtn);
    btnLayout->addWidget(m_openBtn);

    root->addWidget(title);
    root->addWidget(splitter, 1);
    root->addLayout(btnLayout);

    connect(m_list, &QListWidget::currentRowChanged, this, &SavedStoriesDialog::onStoryClicked);
    connect(m_deleteBtn, &QPushButton::clicked, this, &SavedStoriesDialog::onDeleteClicked);
    connect(m_openBtn,   &QPushButton::clicked, this, &SavedStoriesDialog::onOpenClicked);
    connect(closeBtn,    &QPushButton::clicked, this, &QDialog::reject);

    loadList();
}

void SavedStoriesDialog::loadList() {
    m_stories = m_db->loadAllStories();
    m_list->clear();

    bool empty = m_stories.isEmpty();
    m_emptyLabel->setVisible(empty);
    m_list->setVisible(!empty);

    for (const auto& s : m_stories) {
        QString label = QString("📖 %1\n👦 %2 · %3")
            .arg(s.title, s.childName,
                 s.createdAt.toString("d MMM yyyy"));
        m_list->addItem(label);
    }
}

void SavedStoriesDialog::onStoryClicked(int row) {
    if (row < 0 || row >= m_stories.size()) return;

    const auto& meta = m_stories[row];
    m_selectedId = meta.id;

    // Загружаем полную сказку
    StoryData full = m_db->loadStory(m_selectedId);
    m_preview->setHtml(QString(R"(
        <h3 style='color:#4a1fa6;'>%1</h3>
        <p style='color:#7a6090; font-size:12px;'>
            Герой: %2 · Место: %3<br>
            Создана: %4
        </p>
        <hr/>
        <p style='font-size:14px; line-height:160%%;'>%5</p>
    )").arg(
        full.title, full.hero, full.place,
        full.createdAt.toString("d MMMM yyyy"),
        full.text.toHtmlEscaped().replace("\n", "<br>")
    ));

    m_deleteBtn->setEnabled(true);
    m_openBtn->setEnabled(true);
}

void SavedStoriesDialog::onDeleteClicked() {
    if (m_selectedId < 0) return;
    auto ans = QMessageBox::question(
        this, "Удалить сказку?",
        "Вы уверены, что хотите удалить эту сказку?\nОтменить действие нельзя.",
        QMessageBox::Yes | QMessageBox::No
    );
    if (ans == QMessageBox::Yes) {
        m_db->deleteStory(m_selectedId);
        m_selectedId = -1;
        m_preview->clear();
        m_deleteBtn->setEnabled(false);
        m_openBtn->setEnabled(false);
        loadList();
    }
}

void SavedStoriesDialog::onOpenClicked() {
    if (m_selectedId < 0) return;
    StoryData full = m_db->loadStory(m_selectedId);
    emit storySelected(full);
    accept();
}
