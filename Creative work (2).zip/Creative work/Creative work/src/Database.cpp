#include "Database.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QStandardPaths>
#include <QDir>
#include <QDebug>

const QString Database::DB_FILE = "fairytales.db";

Database::Database(QObject* parent) : QObject(parent) {
    m_db = QSqlDatabase::addDatabase("QSQLITE", "fairytale_connection");
}

Database::~Database() {
    if (m_db.isOpen()) m_db.close();
}

bool Database::open() {
    // Сохраняем БД в папке пользователя
    QString dataPath = QStandardPaths::writableLocation(
        QStandardPaths::AppDataLocation
    );
    QDir().mkpath(dataPath);
    m_db.setDatabaseName(dataPath + "/" + DB_FILE);

    if (!m_db.open()) {
        qWarning() << "Не удалось открыть БД:" << m_db.lastError().text();
        return false;
    }
    return createTables();
}

bool Database::isOpen() const {
    return m_db.isOpen();
}

bool Database::createTables() {
    QSqlQuery q(m_db);  // явно указываем соединение
    return q.exec(R"(
        CREATE TABLE IF NOT EXISTS stories (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            child_name  TEXT,
            age_group   INTEGER,
            hero        TEXT,
            hero_trait  TEXT,
            place       TEXT,
            problem     TEXT,
            helper      TEXT,
            magic_item  TEXT,
            ending      INTEGER,
            title       TEXT,
            story_text  TEXT,
            created_at  TEXT
        )
    )");
}

bool Database::saveStory(StoryData& story) {
    if (!m_db.isOpen()) {
        qWarning() << "saveStory: БД не открыта!";
        return false;
    }
    QSqlQuery q(m_db);  // явно указываем соединение
    q.prepare(R"(
        INSERT INTO stories
            (child_name, age_group, hero, hero_trait, place, problem,
             helper, magic_item, ending, title, story_text, created_at)
        VALUES
            (:child_name, :age_group, :hero, :hero_trait, :place, :problem,
             :helper, :magic_item, :ending, :title, :story_text, :created_at)
    )");

    q.bindValue(":child_name",  story.childName);
    q.bindValue(":age_group",   static_cast<int>(story.ageGroup));
    q.bindValue(":hero",        story.hero);
    q.bindValue(":hero_trait",  story.heroTrait);
    q.bindValue(":place",       story.place);
    q.bindValue(":problem",     story.problem);
    q.bindValue(":helper",      story.helper);
    q.bindValue(":magic_item",  story.magicItem);
    q.bindValue(":ending",      static_cast<int>(story.ending));
    q.bindValue(":title",       story.title);
    q.bindValue(":story_text",  story.text);
    q.bindValue(":created_at",  story.createdAt.toString(Qt::ISODate));

    if (!q.exec()) {
        qWarning() << "Ошибка сохранения:" << q.lastError().text();
        return false;
    }
    story.id = q.lastInsertId().toInt();
    return true;
}

bool Database::deleteStory(int id) {
    QSqlQuery q(m_db);
    q.prepare("DELETE FROM stories WHERE id = :id");
    q.bindValue(":id", id);
    return q.exec();
}

StoryData Database::loadStory(int id) {
    QSqlQuery q(m_db);
    q.prepare("SELECT * FROM stories WHERE id = :id");
    q.bindValue(":id", id);
    q.exec();

    StoryData s;
    if (q.next()) {
        s.id        = q.value("id").toInt();
        s.childName = q.value("child_name").toString();
        s.ageGroup  = static_cast<AgeGroup>(q.value("age_group").toInt());
        s.hero      = q.value("hero").toString();
        s.heroTrait = q.value("hero_trait").toString();
        s.place     = q.value("place").toString();
        s.problem   = q.value("problem").toString();
        s.helper    = q.value("helper").toString();
        s.magicItem = q.value("magic_item").toString();
        s.ending    = static_cast<EndingType>(q.value("ending").toInt());
        s.title     = q.value("title").toString();
        s.text      = q.value("story_text").toString();
        s.createdAt = QDateTime::fromString(q.value("created_at").toString(), Qt::ISODate);
    }
    return s;
}

QList<StoryData> Database::loadAllStories() {
    QList<StoryData> list;
    QSqlQuery q(m_db);
    q.exec("SELECT id, child_name, hero, title, created_at FROM stories ORDER BY id DESC");

    while (q.next()) {
        StoryData s;
        s.id        = q.value("id").toInt();
        s.childName = q.value("child_name").toString();
        s.hero      = q.value("hero").toString();
        s.title     = q.value("title").toString();
        s.createdAt = QDateTime::fromString(q.value("created_at").toString(), Qt::ISODate);
        list.append(s);
    }
    return list;
}
